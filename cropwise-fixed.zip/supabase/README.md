# Supabase project (database + Edge Function)

This folder is a standard Supabase CLI project:

- `config.toml` — project config (generated with `supabase init`).
- `migrations/` — SQL schema, RLS policies, triggers, and reference data.
- `functions/ai-assistant/` — the one server-side function, running on
  Supabase's infrastructure (not Netlify).

## Migrations

Run in filename (timestamp) order:

1. `20260722095035_create_profiles_and_farms.sql`
2. `20260722095057_create_soil_and_crops.sql`
3. `20260722095118_create_finance_and_reminders.sql`
4. `20260722095146_create_multi_farming_modules.sql`
5. `20260722095215_create_ai_reference_and_notifications.sql`
6. `20260722095327_seed_reference_data.sql`
7. `20260722103829_add_welcome_notification_trigger.sql`
8. `20260724053238_create_marketplace_listings.sql`
9. `20260724060000_add_reference_data_unique_constraints.sql`

Table creation, policies, and triggers use `CREATE TABLE IF NOT EXISTS`,
`DROP POLICY IF EXISTS`, and `CREATE OR REPLACE FUNCTION`, so those parts are
genuinely safe to re-run. The reference-data seed inserts are now also safe
to re-run, because migration 9 adds unique constraints on `crop_catalog`,
`government_schemes`, and `knowledge_articles` so their existing
`ON CONFLICT DO NOTHING` clauses actually have something to conflict on.

## Deploy for free

```
npm install -g supabase
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase db push
supabase functions deploy ai-assistant
```

## Optional: enable real AI responses

Without this, the function still works — it falls back to rule-based
farming advice instead of erroring out.

```
supabase secrets set OPENAI_API_KEY=your-key-here
```
